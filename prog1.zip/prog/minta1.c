//feladat: beírsz egy szót amiben vannak számok is parancssorba és duplázzon meg minden számot

#include<stdio.h>
#include<stdlib.h>
#include<ctype.h>

typedef char * string;

string double_digit(const char* original)
{
    char * s=malloc((sizeof(char) * sizeof(original))* 2); // a sizeof a '\0' is beleszámolja

    int poz =0;
    for(int i=0; original[i]!='\0';i++)
    {
        s[poz]=original[i];
        poz++;

        if (isdigit(original[i]))
        {
            s[poz]=original[i];
            poz++;

        }
    }
    s[poz]='\0';
    return s;
}

int main(int argc, char*argv[])
{
    if(argc!=2)
    {
        fprintf(stderr,"Hibas parameterezes!\n");
        exit(1);
    }

    char* newstring=double_digit(argv[1]);
    puts(newstring);

    free(newstring);


    return 0;
}