#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

void delete_uppercase(const char* original)
{
    int meret = strlen(original);
    char betuk[26];
    int k = 0;
    for (char i = 'A'; i <= 'Z'; i++)
    {
        betuk[k] = i;
        k++;
    }

    int rossz = 0;
    char masolat[meret];
    int l = 0;
    for (int i = 0; i < meret; i++)
    {
        for (int j = 0; j < 26; j++)
        {
            if(original[i] == betuk[j])
            {
                rossz = 1;
                break;
            }
            else
            {
                rossz = 0;
            }
        }
        if(rossz == 0)
        {
            masolat[l] = original[i];
            l++;
        }

    }   

    printf("%s\n", masolat);
}

int main(int argc, char * argv[])
{
    if(argc == 2)
    {
        char *szo = argv[1];
        delete_uppercase(szo);
    }
    else
    {
        fprintf(stderr, "Hatalmas a baj, nem adtal meg egyetlen szot sem!\n");
        exit(1);
    }

    return 0;

}