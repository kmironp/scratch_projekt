#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <ctype.h>

//my strfry
void shuffle(int n, char* tomb)
{
    for (int i = n-1; i > 1; i--)
    {
        int j = rand() % (0 - i);
        char tmp = tomb[j];
        tomb[j] = tomb[i];
        tomb[i] = tmp; 
    }
    
}

void kiir(char *tomb, int hossz)
{

for (int i = 0; i < hossz; i++)
    {
        printf("%c", tomb[i]);
    }
}

int main()
{

    char *tomb = malloc(256);
    strcpy(tomb, "EzKellemetlenUgymond");
    int hossz = strlen(tomb);

    printf("Eredeti szo:\n%s\nKeverve:\n", tomb);

    srand(time(NULL));
    
    shuffle(hossz, tomb);
    kiir(tomb,hossz);
    
    free(tomb);

    return 0;
}

//my strdup
char *ft_strdup(const char *s1)
{
  char *str;
  size_t size = strlen(s1) + 1;

  str = malloc(size);
  if (str) {
    memcpy(str, s1, size);
  }
  return str;
}

int main()
{

    char *s = "F4hk6 5";
    char *jo = ft_strdup(s);
    jo[2] = '.';
    printf("%s\n", s);
    printf("%s\n", jo);
    

    return 0;
}

//my strcmp
//strcmpi, ami nem kulonbozteti meg a kis es nagybetuket

int strcmpi(const char* s1, const char* s2)
{
    if (strlen(s1) != strlen(s2))
    {
        printf("Meg csak nem is ugyanolyan hosszu a ket szo.. :|");
        exit(-1);
    }
    else
    {
        int size = strlen(s1);
        
        for (int i = 0; i < size; i++)
        {
            if (s1[i] != s2[i])
            {
                if (((char)s1[i] + 32) != (char)s2[i] && ((char)s1[i] - 32) != (char)s2[i])
                {
                    printf("Itt eltereseket velek felfedezni.");
                    exit(-1);
                }
                
            }
            
        }
        
    }
    printf("A(z) \"%s\" szo es a(z) \"%s\" szo tokeletesen megegyezik!\n", s1, s2);

    return 1;
}
//kis nagy betu erzekeny
int strcmp(const char *X, const char *Y)
{
    while (*X)
    {
        // if characters differ, or end of the second string is reached
        if (*X != *Y) {
            break;
        }
 
        // move to the next pair of characters
        X++;
        Y++;
    }
 
    // return the ASCII difference after converting `char*` to `unsigned char*`
    return *(const unsigned char*)X - *(const unsigned char*)Y;
}

int main()
{

    char* s1 = {"ALMa"};
    char* s2 = {"alma"};

    strcmpi(s1,s2);
    int x = strcmp(s1,s2);
 
    if (x > 0) {
        printf("%s", "X is greater than Y");
    }
    else if (x < 0) {
        printf("%s", "X is less than Y");
    }
    else {
        printf("%s", "X is equal to Y");
    }

    return 0;
}

//my strstr

int compare(const char *X, const char *Y)
{
    while (*X && *Y)
    {
        if (*X != *Y) {
            return 0;
        }
 
        X++;
        Y++;
    }
 
    return (*Y == '\0');
}
 
// Function to implement `strstr()` function
const char* strstr(const char* X, const char* Y)
{
    while (*X != '\0')
    {
        if ((*X == *Y) && compare(X, Y)) {
            return X;
        }
        X++;
    }
 
    return NULL;
}
 
// Implement `strstr()` function in C
int main()
{
    char *X = "Techie Delight - Ace the Technical Interviews";
    char *Y = "Ace";
 
    printf("%s\n", strstr(X, Y));
 
    return 0;
}

//my strtok

#define DICT_LEN 256

int *create_delim_dict(char *delim)
{
    int *d = (int*)malloc(sizeof(int)*DICT_LEN);
    memset((void*)d, 0, sizeof(int)*DICT_LEN);

    int i;
    for(i=0; i< strlen(delim); i++) {
        d[delim[i]] = 1;
    }
    return d;
}



char *my_strtok(char *str, char *delim)
{

    static char *last, *to_free;
    int *deli_dict = create_delim_dict(delim);

    if(!deli_dict) {
        return NULL;
    }

    if(str) {
        last = (char*)malloc(strlen(str)+1);
        if(!last) {
            free(deli_dict);
        }
        to_free = last;
        strcpy(last, str);
    }

    while(deli_dict[*last] && *last != '\0') {
        last++;
    }
    str = last;
    if(*last == '\0') {
        free(deli_dict);
        free(to_free);
        return NULL;
    }
    while (*last != '\0' && !deli_dict[*last]) {
        last++;
    }

    *last = '\0';
    last++;

    free(deli_dict);
    return str;
}

int main()
{
    char * str = "- This, a sample string.";
    char *del = " ,.-";
    char *s = my_strtok(str, del);
    while(s) {
        printf("%s\n", s);
        s = my_strtok(NULL, del);
    }
    return 0;
}

//my strcat

char* my_strcat(char* destination, const char* source)
{
    // make `ptr` point to the end of the destination string
    char* ptr = destination + strlen(destination);
 
    // appends characters of the source to the destination string
    while (*source != '\0') {
        *ptr++ = *source++;
    }
 
    // null terminate destination string
    *ptr = '\0';
 
    // the destination is returned by standard `strcat()`
    return destination;
}
 
// Implement `strcat()` function in C
int main()
{
    char* str = (char*)calloc(100, 1);
 
    my_strcat(str, "Techie ");
    my_strcat(str, "Delight ");
    my_strcat(str, "– ");
    my_strcat(str, "Ace ");
    my_strcat(str, "the ");
    my_strcat(str, "Technical ");
    my_strcat(str, "Interviews");
 
    puts(str);
 
    return 0;
}