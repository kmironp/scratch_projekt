#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

void shuffle(int n, char* tomb)
{
    for (int i = n-1; i > 1; i--)
    {
        int j = rand() % (0 - i);
        char tmp = tomb[j];
        tomb[j] = tomb[i];
        tomb[i] = tmp; 
    }
    
}

void kiir(char *tomb, int hossz)
{

for (int i = 0; i < hossz; i++)
    {
        printf("%c", tomb[i]);
    }
}

int main()
{

    char *tomb = malloc(256);
    strcpy(tomb, "EzKellemetlenUgymond");
    int hossz = strlen(tomb);

    printf("Eredeti szo:\n%s\nKeverve:\n", tomb);

    srand(time(NULL));
    
    shuffle(hossz, tomb);
    kiir(tomb,hossz);
    
    free(tomb);

    return 0;
}