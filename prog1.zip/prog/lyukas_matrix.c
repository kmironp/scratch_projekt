#include <stdio.h>
#include <time.h>
#include <stdlib.h>

#define MERET 9

typedef struct
{
    int paros;
    int paratlan;
} Szamok;

Szamok osszesit(int matrix[MERET][MERET])
{
    Szamok s;
    for (int i = 1; i < MERET - 1; i++)
    {
        for (int j = 1; j < MERET - 1; j++)
        {
            if (matrix[i][j] % 2 == 0)
            {
                s.paros += matrix[i][j];
            }
            else
                s.paratlan += matrix[i][j];
        }
    }
    return s;
}

void print_matrix(int matrix[MERET][MERET])
{
    for (int i = 0; i < MERET; i++)
    {
        for (int j = 0; j < MERET; j++)
        {
            printf("%d ", matrix[i][j]);
        }
        puts("");
    }
}

int main()
{
    srand(1980);
    int matrix[MERET][MERET] = {0};
    for (int i = 0; i < MERET; i++)
    {
        for (int j = 0; j < MERET; j++)
        {
            int szam = (rand() % (785 - 242 + 1)) + 242;
            matrix[i][j] = szam;
        }
    }
    print_matrix(matrix);
    int result1 = osszesit(matrix).paros;
    int result2 = osszesit(matrix).paratlan;
    puts("");
    printf("A matrix kereteben levo paros szamok osszege: %d\n", result1);
    printf("A matrix kereteben levo paratlan szamok osszege: %d\n", result2);
}