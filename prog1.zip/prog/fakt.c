#include <stdio.h>

void findFact(int n,int *f)
		{
        int i;

       *f =1;
       for(i=1;i<=n;i++)
       *f=*f*i;
       }


//permutacio
void changePosition(char *ch1, char *ch2)
{
    char tmp;
    tmp = *ch1;
    *ch1 = *ch2;
    *ch2 = tmp;
}
void charPermu(char *cht, int stno, int endno)
{
   int i;
   if (stno == endno)
     printf("%s  ", cht);
   else
   {
       for (i = stno; i <= endno; i++)
       {
          changePosition((cht+stno), (cht+i));
          charPermu(cht, stno+1, endno);
          changePosition((cht+stno), (cht+i)); 
       }
   }
}

int main()
{
         int fact;
         int num1;
		printf("\n\n Pointer : Find the factorial of a given number :\n"); 
		printf("------------------------------------------------------\n");	
		printf(" Input a number : ");
		scanf("%d",&num1);		 

         findFact(num1,&fact);
         printf(" The Factorial of %d is : %d \n\n",num1,fact);

        //permutacio
        char str[] = "juh";
   printf("\n\n Pointer : Generate permutations of a given string :\n"); 
   printf("--------------------------------------------------------\n"); 
    int n = strlen(str);
    printf(" The permutations of the string are : \n");
    charPermu(str, 0, n-1);
     printf("\n\n");




         return 0;
}
