#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <ctype.h>

void veletlen(const int also, const int felso, const int meret, int tomb[])
{
    printf("\nA generalt szamok: ");
    for (int i = 0; i < meret; i++)
    {
        int tmp;
        tmp = rand() % (also - felso) + also;
        
        for (int j = 0; j < meret; j++)
        {
            while (tomb[j] == tmp)
            {
                tmp = rand() % (also - felso) + also;
                j = 0;
            }
            
        }

        tomb[i] = tmp;
        printf("%d ", tomb[i]);
    }
    printf("\n");
}

void rendezes(int tomb[], int be)
{

    for (int i=0; i < be -1 ; i++) 
    {
        int min = i;
        for (int j = i + 1; j < be; j++) 
        {
            if(tomb[min] > tomb[j]) 
            {
                min = j;
            }
        }
        if (min != i)
        {
            int tmp = tomb[min];
            tomb[min] = tomb[i];
            tomb[i] = tmp;
        }
    }
}


int main()
{  
    int meret;
    int also;
    int felso;

    printf("Hany db szamot kersz? ");
    scanf("%d", &meret);
    printf("Also hatar: ");
    scanf("%d", &also);
    printf("Felso hatar (zart intervallum): ");
    scanf("%d", &felso);

    int tomb[meret];

    srand(time(NULL));
    veletlen(also,felso,meret,tomb);
    rendezes(tomb,meret);

    printf("Allitolag rendezett tomb: \n");
    for (int i = 0; i < meret; i++)
    {
        printf("%d ", tomb[i]);
    }
    
return 0;
}