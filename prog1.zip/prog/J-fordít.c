//feladat: olvasd be a szoveg.txt fajlt és irasd ki hogy hány szo van benne hany palindrom szó
//         van benne mennyi a palindrom szavak aránya és hozz létre egy új fajlt amiben a palidrom szavak vannak kiirva

#include<stdio.h>
#include<string.h>
#include<stdlib.h>

#define SIZE 500

void fordit(char *p)
{
    char temp;
    int i = 0, j =0;  
    j = strlen (p) - 1;
    while ( i < j)
    {
    temp = p[j];
    p[j] = p[i];
    p[i] = temp;
    i++;
    j--;
    }
}

int main()
{
    FILE *f=fopen("szók.txt","r");

    if(f==NULL)
    {
        fprintf(stderr,"Hiba");
        exit(1);
    }

    FILE *out=fopen("outs.txt","w");
    if(out==NULL)
    {
        fprintf(stderr,"Hiba2");
        exit(1);
    }

    char sor[SIZE];
    int szavak=0;
    int palindrom=0;

    char*p;
    int hossz = 5;
    int k = 0;

    while(fgets(sor,SIZE,f)!=NULL)
    {
        sor[strlen(sor)-1]='\0';

        p=strtok(sor,"\n");

        while(p!=NULL)
        {
            int meret = strlen(p);

            if((k == hossz - 1) || (k == hossz - 2 ))
            {
                fordit(p);
                
                fprintf(out,"%s\n",p);
            }
            k++;

            p=strtok(NULL," ");
        }
        
    }

    fclose(f);
    fclose(out);
    puts("out.txt allomany letrehozve");


    return 0;
}