#include <stdio.h>
#include <stdlib.h>

#define SIZE 5

void feltolt(const int n, int matrix[n][n])
{
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            matrix[i][j] = rand() % (243 - 125 + 1) + 125;
        }
    }
}

void kiir(const int n, int matrix[n][n])
{
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            printf("%d ", matrix[i][j]);
        }

        puts("");
    }
}

void kiir_kotojel(const int n, int matrix[n][n])
{
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if((j == n - 1))
            {
                printf("%d", matrix[i][j]);
            }
            else
            {
                printf("%d-", matrix[i][j]);
            }            
        }

        puts("");
    }
}

int main(int argc, char *argv[])
{
    srand(1234);

    printf("Eredeti:\n");
    int matrix[SIZE][SIZE];
    feltolt(SIZE, matrix);
    kiir(SIZE, matrix);
    puts("");
    printf("Modositott:\n");
    kiir_kotojel(SIZE, matrix);

    return 0;
}