//feladat: olvasd be a numbers.csv fájlt és azokat a számokat amikben pont van add össze

#include<stdio.h>
#include<string.h>
#include<stdlib.h>

#define SIZE 200

int main()
{
    FILE *f=fopen("numbers.csv","r");

    char sor[SIZE];
    char *p;

    double sum=0;

    while(fgets(sor,SIZE,f)!=NULL)
    {
        p=strtok(sor,";");
        if(strchr(p,'.')!=0) //ha van benne pont memóriacím ha nincs 0
        {
            sum+=atof(p);
        }
        p=strtok(NULL,";");
        if(strchr(p,'.')!=0) //ha van benne pont memóriacím ha nincs 0
        {
            sum+=atof(p);
        }
        p=strtok(NULL,";");
        if(strchr(p,'.')!=0) //ha van benne pont memóriacím ha nincs 0
        {
            sum+=atof(p);
        }

    }

    printf("Az angol szamok osszege: %.3lf\n",sum);
    fclose(f);

    return 0;
}