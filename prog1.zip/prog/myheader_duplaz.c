#include <stdio.h>

int duplaz(int n)
{
    return 2 * n;
}
