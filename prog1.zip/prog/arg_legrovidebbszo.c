#include <stdio.h>
#include <string.h>
#include <stdlib.h>

//legrövidebb szavak (409a)

int main(int argc, char * argv[])
{
    if(argc <= 1)
    {
        fprintf(stderr, "Hatalmas a baj, nem adtal meg egyetlen szot sem!\n");
        exit(1);
    }
    else if(argc > 1)
    {
        int min = strlen(argv[1]);

        for (int i = 1; i < argc; i++)
        {
            if (strlen(argv[i]) < min)
            {
                min = strlen(argv[i]);
            }    
        }

        for (int i = 1; i < argc; i++)
        {
            if (strlen(argv[i]) == min)
            {
                printf("%s\n", argv[i]);
            }   
        }
    }

    return 0;
}