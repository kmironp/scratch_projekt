#include <stdio.h>
#include <string.h>
#include <stdlib.h>

//strcmpi, ami nem kulonbozteti meg a kis es nagybetuket

int strcmpi(const char* s1, const char* s2)
{
    if (strlen(s1) != strlen(s2))
    {
        printf("Meg csak nem is ugyanolyan hosszu a ket szo.. :|");
        exit(-1);
    }
    else
    {
        int size = strlen(s1);
        
        for (int i = 0; i < size; i++)
        {
            if (s1[i] != s2[i])
            {
                if (((char)s1[i] + 32) != (char)s2[i] && ((char)s1[i] - 32) != (char)s2[i])
                {
                    printf("Itt eltereseket velek felfedezni.");
                    exit(-1);
                }
                
            }
            
        }
        
    }
    printf("A(z) \"%s\" szo es a(z) \"%s\" szo tokeletesen megegyezik!\n", s1, s2);

    return 1;
}
//kis nagy betu erzekeny
int strcmp(const char *X, const char *Y)
{
    while (*X)
    {
        // if characters differ, or end of the second string is reached
        if (*X != *Y) {
            break;
        }
 
        // move to the next pair of characters
        X++;
        Y++;
    }
 
    // return the ASCII difference after converting `char*` to `unsigned char*`
    return *(const unsigned char*)X - *(const unsigned char*)Y;
}

int main()
{

    char* s1 = {"ALMa"};
    char* s2 = {"alma"};

    strcmpi(s1,s2);
    int x = strcmp(s1,s2);
 
    if (x > 0) {
        printf("%s", "X is greater than Y");
    }
    else if (x < 0) {
        printf("%s", "X is less than Y");
    }
    else {
        printf("%s", "X is equal to Y");
    }

    return 0;
}