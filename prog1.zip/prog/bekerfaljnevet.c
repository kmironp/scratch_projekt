#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//fájlban lévő sorok száma (409c) 

#define SIZE 100

int main(int argc, char* argv[])
{
    FILE *f = fopen(argv[1], "r");

 
    if (argc <= 1)
    {
        fprintf(stderr, "Hatalmas hiba adodott! Nem adtad meg a szoveges allomany nevet.");
        exit(1);
    }
    else if(f == NULL)
    {
        fprintf(stderr, "Rettentoen nagy a baj, nem sikerult megnyitni a %s nevu file-t!\n", argv[1]);
        exit(1);
    }


/* legrovidebb szo
    if(argc > 1)
    {
        int min = strlen(argv[1]);

        for (int i = 1; i < argc; i++)
        {
            if (strlen(argv[i]) < min)
            {
                min = strlen(argv[i]);
            }    
        }

        for (int i = 1; i < argc; i++)
        {
            if (strlen(argv[i]) == min)
            {
                printf("%s\n", argv[i]);
            }   
        }
    }
    */

   //legnagyobb szam
   /*
   int i,n;
    float *element;
	printf("\n\n Pointer : Find the largest element using Dynamic Memory Allocation :\n"); 
	printf("-------------------------------------------------------------------------\n"); 	
    printf(" Input total number of elements(1 to 100): ");
    scanf("%d",&n);
    element=(float*)calloc(n,sizeof(float));  // Memory is allocated for 'n' elements 
    if(element==NULL)
    {
        printf(" No memory is allocated.");
        exit(0);
    }
    printf("\n");
    for(i=0;i<n;++i)  
    {
       printf(" Number %d: ",i+1);
       scanf("%f",element+i);
    }
    for(i=1;i<n;++i)  
    {
       if(*element<*(element+i)) 
           *element=*(element+i);
    }
    printf(" The Largest element is :  %.2f \n\n",*element);

    free(element);
   */

    char sor[SIZE];

    int sorok = 0;
    while(fgets(sor, SIZE, f) != NULL)
    {
        sorok++;
        sor[strlen(sor)] = '\0';
    }

    fclose(f);

    printf("%d", sorok);

    return 0;
}
