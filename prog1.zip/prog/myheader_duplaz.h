#ifndef DUPLAZ_H
#define DUPLAZ_H


int duplaz(int n);

#endif  //DUPLAZ_H
