#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// függvény adjon vissza több értéket (407a), ezúttal struktúrát használjunk

struct muveleteredmeny
{
    int min, max;
    double atlag;
};

typedef struct muveleteredmeny Struct;

void veletlen(const int meret, int tomb[])
{
    printf("\nA tomb elemei: ");
    for (int i = 0; i < meret; i++)
    {
        tomb[i] = rand() % (10 - 99) + 10;
        printf("%d ", tomb[i]);
    }
    printf("\n");
}

Struct muveletek(const int meret, int tomb[])
{
    Struct s;

    s.min = 100;
    s.max = 0;
    s.atlag = 0;

    for (int i = 0; i < meret; i++)
    {
        if (s.min > tomb[i])
        {
            s.min = tomb[i];
        }
        if (s.max < tomb[i])
        {
            s.max = tomb[i];
        }
        s.atlag = s.atlag + tomb[i];
    }

    return s;
}

int main()
{
    int meret = 10;
    int tomb[meret];

    srand(time(NULL));
    veletlen(meret, tomb);

    Struct eredmeny;
    eredmeny = muveletek(meret, tomb);
    printf("Legkisebb elem : %d\n", eredmeny.min);
    printf("Legnagyobb elem : %d\n", eredmeny.max);
    printf("Az elemek atlaga : %.1lf\n", (double)eredmeny.atlag / (double)meret);

    return 0;
}


//


//idoszamolas
struct TIME {
   int seconds;
   int minutes;
   int hours;
};

void differenceBetweenTimePeriod(struct TIME t1,
                                 struct TIME t2,
                                 struct TIME *diff);

int main() {
   struct TIME startTime, stopTime, diff;

   printf("Enter the start time. \n");
   printf("Enter hours, minutes and seconds: ");
   scanf("%d %d %d", &startTime.hours,
         &startTime.minutes,
         &startTime.seconds);

   printf("Enter the stop time. \n");
   printf("Enter hours, minutes and seconds: ");
   scanf("%d %d %d", &stopTime.hours,
         &stopTime.minutes,
         &stopTime.seconds);

   // Difference between start and stop time
   differenceBetweenTimePeriod(startTime, stopTime, &diff);
   printf("\nTime Difference: %d:%d:%d - ", startTime.hours,
          startTime.minutes,
          startTime.seconds);
   printf("%d:%d:%d ", stopTime.hours,
          stopTime.minutes,
          stopTime.seconds);
   printf("= %d:%d:%d\n", diff.hours,
          diff.minutes,
          diff.seconds);
   return 0;
}

// Computes difference between time periods
void differenceBetweenTimePeriod(struct TIME start,
                                 struct TIME stop,
                                 struct TIME *diff) {
   while (stop.seconds > start.seconds) {
      --start.minutes;
      start.seconds += 60;
   }
   diff->seconds = start.seconds - stop.seconds;
   while (stop.minutes > start.minutes) {
      --start.hours;
      start.minutes += 60;
   }
   diff->minutes = start.minutes - stop.minutes;
   diff->hours = start.hours - stop.hours;
}


//komplex
#include <stdio.h>
typedef struct complex {
    float real;
    float imag;
} complex;

complex add(complex n1, complex n2) {
    complex temp;
    temp.real = n1.real + n2.real;
    temp.imag = n1.imag + n2.imag;
    return (temp);
}

int main() {
    complex n1, n2, result;

    printf("For 1st complex number \n");
    printf("Enter the real and imaginary parts: ");
    scanf("%f %f", &n1.real, &n1.imag);
    printf("\nFor 2nd complex number \n");
    printf("Enter the real and imaginary parts: ");
    scanf("%f %f", &n2.real, &n2.imag);

    result = add(n1, n2);

    printf("Sum = %.1f + %.1fi", result.real, result.imag);
    return 0;
}