#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX 2000
#define SIZE 2000

typedef char *string;
typedef struct
{
    char irany[20];
    int tav;
} Adatok;

int feltolt(const string fname, Adatok tomb[])
{
    int index = 0;

    FILE *f = fopen(fname, "r");

    if (f == NULL)
    {
        fprintf(stderr, "Nem sikerült megnyitni.");
        exit(1);
    }

    char sor[SIZE];
    string irany;
    int tav;
    char *p;

    while (fgets(sor, SIZE, f) != NULL)
    {
        sor[strlen(sor) - 1] = '\0';
        p = strtok(sor, " ");
        irany = p;
        p = strtok(NULL, "\n");
        tav = atoi(p);

        if (irany != 0)
        {
            Adatok h;
            strcpy(h.irany, irany);
            h.tav = tav;
            tomb[index] = h;
            index++;
        }
    }

    fclose(f);
    return index;
}

int strcmpi(const char *s1, const char *s2)
{
    if (strlen(s1) != strlen(s2))
    {
        return 0;
    }
    else
    {
        int size = strlen(s1);

        for (int i = 0; i < size; i++)
        {
            if (s1[i] != s2[i])
            {
                if (((char)s1[i] + 32) != (char)s2[i] && ((char)s1[i] - 32) != (char)s2[i])
                {
                    return 0;
                }
            }
        }
    }

    return 1;
}

void szum(int n, Adatok tomb[])
{
    int sum_Y = 0;
    int sum_X = 0;
    char *irany1 = "le";
    char *irany2 = "fel";
    char *irany3 = "jobb";
    char *irany4 = "bal";

    for (int i = 0; i < n; i++)
    {
        if (1 == strcmpi(irany1, tomb[i].irany))
        {
            sum_Y = sum_Y - tomb[i].tav;
        }
        if (1 == strcmpi(irany2, tomb[i].irany))
        {
            sum_Y = sum_Y + tomb[i].tav;
        }
        if (1 == strcmpi(irany3, tomb[i].irany))
        {
            sum_X = sum_X + tomb[i].tav;
        }
        if (1 == strcmpi(irany4, tomb[i].irany))
        {
            sum_X = sum_X - tomb[i].tav;
        }
    }

    printf("x: %d\ny: %d\n", sum_X, sum_Y);
}

int main()
{
    Adatok tomb[MAX];
    const string filename = "input.txt";

    int elemszam = feltolt(filename, tomb);

    szum(elemszam, tomb);

    return 0;
}