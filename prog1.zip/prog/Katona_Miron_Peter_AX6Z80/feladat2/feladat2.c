#include <stdio.h>
#include <time.h>
#include <stdlib.h>

#define SOR 6
#define OSZLOP 8

void feltolt(const int n, const int m, int matrix1[n][m])
{
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            matrix1[i][j] = rand() % (57 - 21 + 1) + 21;
        }
    }
}

void transzponal(const int n, const int m, int matrix1[n][m], int matrix2[m][n])
{
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            matrix2[j][i] = matrix1[i][j];
        }
    }
}

void kiir_e(const int n, const int m, int matrix[n][m])
{
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            printf("%d ", matrix[i][j]);
        }

        puts("");
    }
    printf("\n---\n\n");
}

void kiir_tr(const int n, const int m, int matrix[m][n])
{
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < n; j++)
        {
            printf("%d ", matrix[i][j]);
        }

        puts("");
    }
}

int main()
{
    int A[SOR][OSZLOP]; // eredeti
    int B[OSZLOP][SOR]; // transzpo

    srand(1986);

    feltolt(SOR, OSZLOP, A);

    kiir_e(SOR, OSZLOP, A);

    transzponal(SOR, OSZLOP, A, B);

    kiir_tr(SOR, OSZLOP, B);

    return 0;
}
