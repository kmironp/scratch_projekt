#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#define SIZE 201

int main()
{
    FILE *f = fopen("numbers.txt", "r");

    printf("numbers.txt sikeresen megnyitva\n");
    printf("számok vizsgálata...\n");
    

    FILE *out = fopen("out.txt", "w");
    if (out == NULL)
    {
        fprintf(stderr, "Hiba2");
        exit(1);
    }

    char sor[SIZE];
    int szamok[SIZE];
    char *p;
    

    while (fgets(sor, SIZE, f) != NULL)
    {
        int k = 0;
        sor[strlen(sor) - 1] = '\0';
        p = strtok(sor,"\n");
        szamok[k] = atoi(p);
        k++;

        
        
    }
    fclose(f);
    srand(time(NULL));
    int osszeg = 2022;
    int szum = 0;
    while (1)    
    {
        int tmp1;
        int tmp2;
        tmp1 = rand() % (SIZE - 0) + 0;
        tmp2 = rand() % (SIZE - 0) + 0;

        int egyik = szamok[tmp1];
        int masik = szamok[tmp2];
        szum = egyik + masik;
        
        if(szum == osszeg)
        {
            printf("egyik: %d, masik: %d", egyik, masik);
            fprintf(out, "%d", egyik);
            fprintf(out, "%d", masik);
            break;
        }
    }
    printf("\n");
    

    puts("vizsgalat befejeződött");
    puts("out.txt allomany letrehozve");
    
    fclose(out);

    return 0;
}