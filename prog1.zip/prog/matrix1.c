#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <ctype.h>

void kiir(int n, int matrix[n][n])
{
    for (int sor = 0; sor < n; sor++)
    {
        for (int oszlop = 0; oszlop < n; oszlop++)
        {
            printf("%d\t", matrix[sor][oszlop]);
        }
        puts("");
    }
    
}

int foatlo(int n, int matrix[n][n])
{
    int sum = 0;
    for (int i = 0; i < n; i++)
    {
        sum += matrix[i][i];
    }
    return sum;
}

int * matlo(int n, int matrix[n][n])
{
    int *mellek = malloc(n * sizeof(int));

    int tmp = n-1;
    for (int i = 0; i < n; i++)
    {
        mellek[i] = matrix[i][tmp];
        tmp--;
    }
    return mellek;
}

int atlo_kiir(int *atlok, int n)
{
    int szum = 0;
    printf("\nA mellekato elemei:\n");
    for (int i = 0; i < n; i++)
    {
        printf("%d/6: %d\n", i+1, atlok[i]);
        
        szum = szum + atlok[i];
        
    }
    printf("%d\n", szum);
}

int main()
{
    int matrix[3][3] = 
    {
        {1, 2, 3},
        {5, 6, 7},
        {9, 10, 11},
    };

    int n = 3;

    kiir(n, matrix);

    int *atlok = matlo(n, matrix);

    atlo_kiir(atlok, n);

    free(atlok);

    printf("Foatolo: %d\n", foatlo(n,matrix));

    return 0;
}