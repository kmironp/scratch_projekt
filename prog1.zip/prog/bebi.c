#include <stdio.h>

int main()
{
    printf("szeretlek mirmur <3\n");

    return 0;
}