#include <string.h>
#include <stdio.h>

int main()
{
    char s[] = "Ilyet he";
    char *p;

    puts(s);
    p = strtok(s, " ");
    while (p != NULL)
    {
        p = strtok(NULL, " ");
    }
    
    char s1[] = "Hello";
    printf("%d\n", (int)strlen(s1));
    printf("%d\n", (int)sizeof(s1));
    printf("%d\n", strcmp("Alma", "alma"));
    char s3[100] = "Na ";
    char s2[100] = "csa";

    strcat(s3, s2); //strncat
    puts(s3);

    char s4[] = "Ilyet he -_-";

    puts(s4);

    strcpy(s4 + 6,s4 + 8);

    puts(s4);

    char s5[] = "Az ik jo egy jo hely.";
    int db = 0;
    char *p1;

    p1 = strstr(s5, "jo");
    while (p1 != NULL)
    {
        db++;
        puts(p1);
        p1 = strstr(p1 + 1, "jo");
    }
    
    printf("%d\n", db);
    
    return 0;
}