//feladat: olvasd be a szoveg.txt fajlt és irasd ki hogy hány szo van benne hany palindrom szó
//         van benne mennyi a palindrom szavak aránya és hozz létre egy új fajlt amiben a palidrom szavak vannak kiirva

#include<stdio.h>
#include<string.h>
#include<stdlib.h>

#define SIZE 500

int is_palindrom(char * s)
{
   int i=0;
   int j=strlen(s)-1;

   while(i<j)
   {
       if(s[i]!= s[j])
       {
           return 0;
       }
       i++;
       j--;
   }

   return 1;


}

int main()
{
    FILE *f=fopen("szoveg.txt","r");

    if(f==NULL)
    {
        fprintf(stderr,"Hiba");
        exit(1);
    }

    FILE *out=fopen("out.txt","w");
    if(out==NULL)
    {
        fprintf(stderr,"Hiba2");
        exit(1);
    }

    char sor[SIZE];
    int szavak=0;
    int palindrom=0;

    char*p;

    while(fgets(sor,SIZE,f)!=NULL)
    {
        sor[strlen(sor)-1]='\0';

        p=strtok(sor," ");

        while(p!=NULL)
        {
            szavak++;
            if(is_palindrom(p)==1)
            {
                palindrom++;
                fprintf(out,"%s\n",p);
            }

            p=strtok(NULL," ");
        }
        
    }
    
    printf("Szavak szama: %d\n",szavak);
    printf("Palindrom szavak szama: %d\n",palindrom);
    printf("Palindrom szavak aranya %.1lf%%\n",(double)palindrom / szavak*100);

    fclose(f);
    fclose(out);
    puts("out.txt allomany letrehozve");


    return 0;
}