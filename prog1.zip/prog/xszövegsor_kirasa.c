#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX 100
#define SIZE 200

typedef char * string;
typedef struct
{
    char nev[20];
} Hallgatok;

int feltolt(const string fname, Hallgatok tomb[])
{
    int index = 0;

    FILE *f = fopen(fname, "r");

    if (f == NULL)
    {
        fprintf(stderr, "Nagy a baj.");
        exit(1);
    }
    
    char sor[SIZE];
    string nev;
    char *p;

    while (fgets(sor, SIZE, f) != NULL)
    {
        sor[strlen(sor) - 1] = '\0';
        p = strtok(sor, "\n");
        nev = p;

        if (nev != NULL)
        {
            Hallgatok h;
            strcpy(h.nev, nev);
            tomb[index] = h;
            index++;
        }
            
    }
    
    fclose(f);
    return index;
}

void print_hallgato(int elemszam, Hallgatok tomb[], int szamok[], int db)
{
    for (int i = 0; i < db; i++)
    {
        printf("nev: %s\n", tomb[szamok[i]].nev);
    }
    
    
}

int main(int argc, char* argv[])
{
    int i = 1;
    int j = 0;
    int szamok[MAX];
    while(i != argc)
    {
        szamok[j] = atoi(argv[i]) - 1;
        j++;
        i++;
    }

    Hallgatok tomb[MAX];
    const string filename = "szók.txt";

    int elemszam =  feltolt(filename, tomb);

    print_hallgato(elemszam, tomb, szamok, j);

    return 0;
}