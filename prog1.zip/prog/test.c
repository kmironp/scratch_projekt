#include <stdio.h>
#include <stdlib.h>
#include <time.h>

//függvény adjon vissza több értéket (407a), ezúttal struktúrát használjunk

struct muveleteredmeny
{
int min, max;
double atlag;
};

typedef struct muveleteredmeny Struct;

void veletlen(const int meret, int tomb[])
{
    printf("\nA tomb elemei: ");
    for (int i = 0; i < meret; i++)
    {
        tomb[i] = rand() % (10 - 99) + 10;
        printf("%d ", tomb[i]);
    }
    printf("\n");
}

Struct muveletek(const int meret, int tomb[])
{
    Struct s;
    
    s.min = 100;
    s.max = 0;
    s.atlag = 0;

        for (int i = 0; i < meret; i++)
    {
        if (s.min > tomb[i])
        {
            s.min = tomb[i];
        }
        if (s.max < tomb[i])
        {
            s.max = tomb[i];
        }
        s.atlag = s.atlag + tomb[i];
    }

    return s;
}

int main()
{  
    int meret = 10;
    int tomb[meret];

    srand(time(NULL));
    veletlen(meret,tomb);

    Struct eredmeny;
    eredmeny = muveletek(meret, tomb);
    printf("Legkisebb elem : %d\n", eredmeny.min);
    printf("Legnagyobb elem : %d\n", eredmeny.max);
    printf("Az elemek atlaga : %.1lf\n", (double)eredmeny.atlag/(double)meret);

    return 0;
}