#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char *ft_strdup(const char *s1)
{
  char *str;
  size_t size = strlen(s1) + 1;

  str = malloc(size);
  if (str) {
    memcpy(str, s1, size);
  }
  return str;
}

int main()
{

    char *s = "F4hk6 5";
    char *jo = ft_strdup(s);
    jo[2] = '.';
    printf("%s\n", s);
    printf("%s\n", jo);
    

    return 0;
}