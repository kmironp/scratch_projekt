#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX 100
#define SIZE 200

typedef char * string;
typedef struct
{
    char nev[20];
    int kor;
    char szak[5];
} Hallgatok;

void lowercase(string s)
{
    for (int i = 0; s[i] != '\0'; i++)
    {
        s[i] = tolower(s[i]);
    }
}

int feltolt(const string fname, Hallgatok tomb[])
{
    int index = 0;

    FILE *f = fopen(fname, "r");

    if (f == NULL)
    {
        fprintf(stderr, "Nagy a baj.");
        exit(1);
    }
    
    char sor[SIZE];
    string nev;
    string szak;
    int kor;
    char *p;

    while (fgets(sor, SIZE, f) != NULL)
    {
        sor[strlen(sor) - 1] = '\0';
        p = strtok(sor, ",;");
        nev = p;
        p = strtok(NULL, ",;");
        kor = atoi(p);
        p = strtok(NULL, ",;");
        szak = p;

        lowercase(szak);
        if (szak != NULL)
        {
            Hallgatok h;
            strcpy(h.nev, nev);
            h.kor = kor;
            strcpy(h.szak, szak);
            tomb[index] = h;
            index++;
        }
            
    }
    
    fclose(f);
    return index;
}

void capitalize(string s)
{
    int hossz = strlen(s);

    if (hossz > 0)
    {
        s[0] = toupper(s[0]);
        for (int i = 1; i < hossz; i++)
        {
            s[i] = tolower(s[i]);
        }
        
    }
    
}

void print_hallgato(int n, Hallgatok tomb[])
{
    for (int i = 0; i < n; i++)
    {
        printf("nev: %s, kor: %d, szak: %s\n",tomb[i].nev, tomb[i].kor, tomb[i].szak);
    }
    
}

void printf_atalgkor(int n, Hallgatok tomb[])
{
    double szum = 0;
    double atlag = 0;
    for (int i = 0; i < n; i++)
    {
        szum = szum + tomb[i].kor;
    }
    atlag = (double)szum / (double)n;
    printf("kor: %.2lf\n", atlag);
}

int cmp(const void * jobb, const void * bal)
{
    const Hallgatok * a = jobb;
    const Hallgatok * b = bal;

    return strcmp(a->nev, b->nev);
}

int main()
{
    Hallgatok tomb[MAX];
    const string filename = "nevek.csv";

    int elemszam =  feltolt(filename, tomb);

    for (int i = 0; i < elemszam; i++)
    {
        capitalize(tomb[i].nev);
    }
    
    qsort(tomb, elemszam, sizeof(Hallgatok), cmp);
    print_hallgato(elemszam, tomb);
    printf_atalgkor(elemszam, tomb);

    return 0;
}