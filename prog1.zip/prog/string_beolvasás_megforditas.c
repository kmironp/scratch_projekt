#include <stdio.h>  
#include <string.h>  
int main()  
{  
char str1[50], temp; // declare and initialize the size of string array.  
int i = 0, j =0;  
printf (" Enter a string to be reversed: ");  
scanf( "%s", str1);  
j = strlen (str1) - 1;  // get the length of the string  
// use while loop to define the condition  
while ( i < j)   
{  
// use temp variable to store the characters of str1  
temp = str1[j];  
str1[j] = str1[i];  
str1[i] = temp;  
i++; // i incremented by 1  
j--; // j is decremented by 1  
}  
printf (" The reversed of the string: %s\n", str1);  
return 0;  
}  